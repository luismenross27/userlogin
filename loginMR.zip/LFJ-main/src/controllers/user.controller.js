export const renderUserProfile = (req, res) => res.render("profile");
